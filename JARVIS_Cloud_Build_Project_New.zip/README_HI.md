# JARVIS Hindi Assistant (Android)

यह शुरुआती Android WebView प्रोजेक्ट है। GitHub Actions से debug APK बनाने के लिए workflow `.github/workflows/build-apk.yml` में है।

## ज़रूरी
ZIP को अपने GitHub repository में अकेले upload करने से build नहीं चलेगा। Extract करके पूरी फ़ोल्डर संरचना सहित project files डालें।

## APK
GitHub repository → Actions → `Build JARVIS APK` → सफल run → Artifacts → `jarvis-debug-apk` डाउनलोड करें।

यह demo सामान्य AI उत्तरों से जुड़ा नहीं है। वास्तविक AI बातचीत के लिए सुरक्षित backend/API integration अलग से चाहिए; कोई API key शामिल नहीं है।
